package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.dao.employeedao;
import com.example.demo.model.Department;
import com.example.demo.model.Employee;
import com.example.demo.model.EmployeeDto;

@RestController
public class Employeecontroller {
	@Autowired
	employeedao d1 ;
	
	@GetMapping (value = "/read")
	public List<Employee> getemployee(){
		return d1.getdata();
	}
	@GetMapping( value = "/departmet")
	public List<Department> getdepartment(){
		return d1.getdep();
	}
	@PostMapping(value ="/insert")
	public String insertemployee(@RequestBody Employee emp) {
		d1.insert(emp);
		return "data inserted";
	}
	@DeleteMapping(value = "/delete/{username}")
	public void deleteemployee(@PathVariable String username) {
		
		d1.delete(username);
		
	}
	@PutMapping(value = "/update")
		public String updateemployee(@RequestBody EmployeeDto dto) {
			d1.updateEmployee(dto);
			return "update successfully";
		}
	}
	


