package com.example.demo.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.example.demo.model.Department;
import com.example.demo.model.Employee;
import com.example.demo.model.EmployeeDto;

@Repository
public class employeedao {
	@Autowired
	public JdbcTemplate t1;
	
	public List<Employee> getdata(){
		String sql = "select * from employess";
		List<Employee> list = t1.query(sql, new BeanPropertyRowMapper(Employee.class));
		return list;
		
		
		
	}
	public void insert(Employee e) {
		String depname = e.getDp().getDname();
		System.out.println(depname);
		if(checkdep(e.getDp().getDid())==false) {
			String sql = "insert into department values(?,?)";
					t1.update(sql,new Object[] {e.getDp().getDid(),e.getDp().getDname()});
		}
		String sql = "insert into employess values(?,?,?,?)";
		t1.update(sql,new Object[] {e.getName(),e.getPassword(),e.getEmail(),e.getDp().getDid()});
		
		
	}
	public List<Department> getdep () {
		String sql = "select * from department";
		List<Department> list = t1.query(sql, new BeanPropertyRowMapper(Department.class));
		return list;
	}
	public boolean checkdep(int depid) {
		String sql = "Select did from department";
		List<Integer> dept = t1.queryForList(sql, Integer.class);
		return dept.contains(depid);
	
	}
	public void delete(String name) {
		String sql = "delete from employess where username = ?";
		t1.update(sql,name);
	}
	public void updateEmployee(EmployeeDto dto) {
		String sql = " update employess set password =? , email = ? where username = ?";
				t1.update(sql,new Object[] {dto.getPassword(),dto.getEmail(),dto.getUsername()});
	}
 

}
